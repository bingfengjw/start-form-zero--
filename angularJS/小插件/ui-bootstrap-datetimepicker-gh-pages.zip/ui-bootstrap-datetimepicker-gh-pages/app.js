'use strict';

var app = angular.module('app',[
    'app.controllers',
    'app.directives'
])
